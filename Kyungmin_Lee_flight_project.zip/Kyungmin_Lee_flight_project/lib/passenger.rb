class Passenger
    def initialize(name_str)
        @name = name_str
        @flight_numbers = []
    end
    def name
        @name
    end
    def has_flight?(str)
        if @flight_numbers.include?(str.upcase)
            return true
        end
        false
    end
    def add_flight(str)
       if self.has_flight?(str)
        return true
       else
        @flight_numbers << str.upcase
       end
    end
            
end